/*
 * motoro_control.c
 *
 *  Created on: Dec 7, 2025
 *      Author: Chandramohan
 */


#include "math.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_tim.h"

// ================== ROBOT / MOTOR CONFIG ==================

// ---- Robot geometry (meters) ----
#define WHEEL_RADIUS_M         0.06f     // 6 cm radius  (change if needed)
#define WHEEL_BASE_M           0.30f     // 30 cm between wheel centers

// ---- Motion limits (m/s) ----
#define MAX_WHEEL_LINEAR_MPS   0.8f      // max wheel linear speed (m/s)

// ---- PWM settings ----
// TIM1 and TIM9 should both have the same period (ARR), e.g. 999
#define PWM_TIMER_MAX          999       // must match timer Period in CubeMX

// ---- Direction pin mappings ----
// Left motor direction pins (L298N IN1 / IN2) -> PB4, PB5
#define LEFT_DIR_GPIO_PORT_IN1   GPIOB
#define LEFT_DIR_GPIO_PIN_IN1    GPIO_PIN_5

#define LEFT_DIR_GPIO_PORT_IN2   GPIOB
#define LEFT_DIR_GPIO_PIN_IN2    GPIO_PIN_4

// Right motor direction pins (L298N IN3 / IN4) -> PD10, PD11
#define RIGHT_DIR_GPIO_PORT_IN3  GPIOD
#define RIGHT_DIR_GPIO_PIN_IN3   GPIO_PIN_10

#define RIGHT_DIR_GPIO_PORT_IN4  GPIOD
#define RIGHT_DIR_GPIO_PIN_IN4   GPIO_PIN_11

// ---- PWM Timers / Channels ----
// Provided by CubeMX-generated code
extern TIM_HandleTypeDef htim9;   // left motor PWM
extern TIM_HandleTypeDef htim1;   // right motor PWM

#define LEFT_PWM_HTIM htim9
#define LEFT_PWM_CHANNEL TIM_CHANNEL_1     // TIM1_CH1

#define RIGHT_PWM_HTIM htim1
#define RIGHT_PWM_CHANNEL TIM_CHANNEL_1 // TIM9_CH1

#define MIN_PWM_START  180   // tune (0..PWM_TIMER_MAX). Try 150-300

// ================== HELPER FUNCTIONS ==================

static uint16_t speed_to_pwm(float speed_mps)
{
	float mag = fabsf(speed_mps);

	    if (mag < 0.001f) return 0;

	    if (mag > MAX_WHEEL_LINEAR_MPS) mag = MAX_WHEEL_LINEAR_MPS;

	    float duty = mag / MAX_WHEEL_LINEAR_MPS;
	    uint16_t pwm = (uint16_t)(duty * (float)PWM_TIMER_MAX);

	    // Minimum PWM to overcome stiction
	    if (pwm > 0 && pwm < MIN_PWM_START) pwm = MIN_PWM_START;

	    if (pwm > PWM_TIMER_MAX) pwm = PWM_TIMER_MAX;
	    return pwm;
}

static void set_left_motor(float v_l_mps)
{
    uint16_t pwm = speed_to_pwm(v_l_mps);

    // Direction: adjust HIGH/LOW if "forward" is reversed for your wiring.
    if (v_l_mps >= 0.0f) {
        // Forward: IN1 = 1, IN2 = 0
        HAL_GPIO_WritePin(LEFT_DIR_GPIO_PORT_IN1, LEFT_DIR_GPIO_PIN_IN1, GPIO_PIN_SET);
        HAL_GPIO_WritePin(LEFT_DIR_GPIO_PORT_IN2, LEFT_DIR_GPIO_PIN_IN2, GPIO_PIN_RESET);
    } else {
        // Reverse: IN1 = 0, IN2 = 1
        HAL_GPIO_WritePin(LEFT_DIR_GPIO_PORT_IN1, LEFT_DIR_GPIO_PIN_IN1, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(LEFT_DIR_GPIO_PORT_IN2, LEFT_DIR_GPIO_PIN_IN2, GPIO_PIN_SET);
    }

    __HAL_TIM_SET_COMPARE(&LEFT_PWM_HTIM, LEFT_PWM_CHANNEL, pwm);
//    TIM1->CCR1 = pwm;
}

static void set_right_motor(float v_r_mps)
{
    uint16_t pwm = speed_to_pwm(v_r_mps);

    if (v_r_mps >= 0.0f) {
        // Forward: IN3 = 1, IN4 = 0
        HAL_GPIO_WritePin(RIGHT_DIR_GPIO_PORT_IN3, RIGHT_DIR_GPIO_PIN_IN3, GPIO_PIN_SET);
        HAL_GPIO_WritePin(RIGHT_DIR_GPIO_PORT_IN4, RIGHT_DIR_GPIO_PIN_IN4, GPIO_PIN_RESET);
    } else {
        // Reverse: IN3 = 0, IN4 = 1
        HAL_GPIO_WritePin(RIGHT_DIR_GPIO_PORT_IN3, RIGHT_DIR_GPIO_PIN_IN3, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(RIGHT_DIR_GPIO_PORT_IN4, RIGHT_DIR_GPIO_PIN_IN4, GPIO_PIN_SET);
    }

    __HAL_TIM_SET_COMPARE(&RIGHT_PWM_HTIM, RIGHT_PWM_CHANNEL, pwm);
//    TIM9->CCR1 = pwm;

}
